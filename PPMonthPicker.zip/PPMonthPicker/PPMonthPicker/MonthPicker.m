

//
//  MonthPicker.m
//  PPMonthPicker
//
//  Created by macfai on 16/3/10.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import "MonthPicker.h"
typedef enum{
    monthPickerToolBarItemTypeCancel = 1,
    monthPickerToolBarItemTypeDone
}monthPickerToolBarItemType;

@interface MonthPicker() <UIPickerViewDataSource, UIPickerViewDelegate>

@property (nonatomic, strong) UIPickerView *monthPickerView;
@property (nonatomic, strong) NSArray *years;
@property (nonatomic, strong) NSArray *months;
@property (nonatomic, strong) UIView *coverView;
@property (nonatomic, strong) UIView *toolBar;
@property (nonatomic, strong) NSArray *toolBarItems;
@property (nonatomic, assign) NSInteger currentYearIndex;
@property (nonatomic, assign) NSInteger currentMonthIndex;

@end

@implementation MonthPicker

- (id)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:[self calculateFrame]];
    
    if (self) {
        [self loadData];
        [self setupPickerView];
        [self configureToolBar];
        [self.monthPickerView selectRow:self.currentYearIndex inComponent:0 animated:YES];
        [self.monthPickerView selectRow:self.currentMonthIndex inComponent:1 animated:YES];
    }
    return self;
}

- (void)configureToolBar{
    
    
    _toolBar = [[UIView alloc] init];
    _toolBar.backgroundColor = TOOLBAR_ITEM_BG_COLOR;
    //    _toolBar.frame = CGRectMake(0, 0, DATE_PICKER_VIEW_WIDTH, DATE_PICKER_VIEW_TOOLBAR_HEIGHT);
    NSArray *itemTitles = @[@"取消", @"", @"", @"", @"确定"];
    NSMutableArray *toolBarItems = [NSMutableArray array];
    NSInteger itemTag = 0;
    for(NSString *itemTitle in itemTitles){
        UIButton *item = [UIButton buttonWithType:UIButtonTypeCustom];
        [item setTitle:itemTitle forState:UIControlStateNormal];
        [item setTitleColor:TOOLBAR_ITEM_TEXT_COLOR forState:UIControlStateNormal];
        [item setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
        [item addTarget:self action:@selector(toolBarItmeClick:) forControlEvents:UIControlEventTouchUpInside];
        item.hidden = itemTitle.length == 0;
        if(itemTitle.length > 0){
            itemTag ++;
            item.tag = itemTag;
        }
        [_toolBar addSubview:item];
        [toolBarItems addObject:item];
    }
    [self addSubview:_toolBar];
    self.toolBarItems = [toolBarItems copy];
}

- (void)setFrame:(CGRect)frame{
    [super setFrame:[self calculateFrame]];
}

- (CGRect)calculateFrame{
    return CGRectMake((SCREEN_WIDTH - DATE_PICKER_VIEW_WIDTH) * 0.5, SCREEN_HEIGHT, DATE_PICKER_VIEW_WIDTH, YARE_MONTH_PICKER_VIEW_HEIGHT);
}

- (void)setupPickerView{
    _monthPickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 216)];//216是默认高度
    _monthPickerView.dataSource = self;
    _monthPickerView.delegate = self;
    _monthPickerView.backgroundColor = DATE_PICKER_VIEW_BG_COLOR;
    [self addSubview:_monthPickerView];
}

- (void)loadData{
    NSMutableArray *tempYears = [NSMutableArray array];
    for(NSInteger i = 1970; i < 2100; i ++){
        [tempYears addObject:[NSString stringWithFormat:@"%ld", (long)i]];
    }
    self.years = [tempYears copy];
    for(NSInteger index = 0; index < self.years.count; index ++){
        if([self.years[index] isEqualToString:[self thisYear]]){
            self.selectedYear = self.years[index];
            self.currentYearIndex = index;
        }
    }
    
    self.months = @[@"1", @"2", @"3", @"4", @"5", @"6", @"7", @"8", @"9", @"10", @"11", @"12"];
    for(NSInteger index = 0; index < self.months.count; index ++){
        if([self.months[index] isEqualToString:[self thisMonth]]){
            self.selectedMonth = self.months[index];
            if(self.selectedMonth.length == 1){
                self.selectedMonth = [NSString stringWithFormat:@"0%@", self.selectedMonth];
            }
            self.currentMonthIndex = index;
        }
    }
}

- (NSString *)thisYear{
    unsigned units  = NSMonthCalendarUnit | NSDayCalendarUnit | NSYearCalendarUnit;
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
    NSDateComponents *comp = [calendar components:units fromDate:[NSDate date]];
    return [NSString stringWithFormat:@"%ld", (long)[comp year]];
}

- (NSString *)thisMonth{
    unsigned units  = NSMonthCalendarUnit | NSDayCalendarUnit | NSYearCalendarUnit;
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
    NSDateComponents *comp = [calendar components:units fromDate:[NSDate date]];
    return [NSString stringWithFormat:@"%ld", (long)[comp month]];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if(component == 0){
        return self.years.count;
    }
    return self.months.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(component == 0){
        return self.years[row];
    }
    return self.months[row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(component == 0){
        self.selectedYear = self.years[row];
    }else{
        self.selectedMonth = self.months[row];
        if(self.selectedMonth.length == 1){
            self.selectedMonth = [NSString stringWithFormat:@"0%@", self.selectedMonth];
        }
    }
}

- (void)toolBarItmeClick:(UIBarButtonItem *)item{
    switch (item.tag) {
        case monthPickerToolBarItemTypeCancel:
            if([self.delegate respondsToSelector:@selector(monthPickerViewDidClickCancel:)]){
                [self.delegate monthPickerViewDidClickCancel:self];
            }
            [self hide];
            break;
        case monthPickerToolBarItemTypeDone:
            if([self.delegate respondsToSelector:@selector(monthPickerViewDidClickDone:)]){
                [self.delegate monthPickerViewDidClickDone:self];
            }
            [self hide];
            break;
        default:
            break;
    }
}

- (void)show{
    
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    __block typeof(self) bself = self;
    [UIView animateWithDuration:0.25 animations:^{
        
        bself.transform = CGAffineTransformMakeTranslation(0, -bself.frame.size.height);
    }];
}

- (void)hide{
    __block typeof(self) bself = self;
    [UIView animateWithDuration:0.25 animations:^{
        bself.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        [bself removeFromSuperview];
    }];
}

- (void)layoutSubviews{
    
    [super layoutSubviews];
    self.toolBar.frame = CGRectMake(0, 0, DATE_PICKER_VIEW_WIDTH, DATE_PICKER_VIEW_TOOLBAR_HEIGHT);
    
    for(NSInteger index = 0; index < self.toolBarItems.count; index ++){
        CGFloat item_W = self.toolBar.bounds.size.width / self.toolBarItems.count;
        CGFloat item_H = self.toolBar.bounds.size.height;
        CGFloat item_X = item_W * index;
        CGFloat item_Y = 0;
        UIButton *item = self.toolBarItems[index];
        item.frame = CGRectMake(item_X, item_Y, item_W, item_H);
    }
}

@end
