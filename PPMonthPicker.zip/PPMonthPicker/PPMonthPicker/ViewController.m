//
//  ViewController.m
//  PPMonthPicker
//
//  Created by macfai on 16/3/10.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import "ViewController.h"
#import "MonthPicker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
//可查看代理方法进行所选日期的获取
- (IBAction)show:(id)sender {
    
    MonthPicker *m = [[MonthPicker alloc]init];
    [m show];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
